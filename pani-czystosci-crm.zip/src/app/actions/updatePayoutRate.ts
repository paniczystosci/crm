'use server'

import { createClient } from '@/lib/supabaseServer'

export async function updatePayoutRate(userId: string, newRate: string) {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('profiles')
    .update({ payout_rate: newRate })
    .eq('id', userId)

  if (error) {
    console.error('Error updating payout rate:', error)
    return { success: false, error: error.message }
  }

  return { success: true }
}